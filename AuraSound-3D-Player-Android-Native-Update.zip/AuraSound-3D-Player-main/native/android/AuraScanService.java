package com.aurasound.player;
import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
public class AuraScanService extends Service {
  static final String CHANNEL="aurasound_scan";
  @Override public void onCreate(){super.onCreate();
    if(Build.VERSION.SDK_INT>=26){
      NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
      nm.createNotificationChannel(new NotificationChannel(CHANNEL,"AuraSound music scan",NotificationManager.IMPORTANCE_LOW));
    }
    Notification n=new NotificationCompat.Builder(this,CHANNEL)
      .setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle("AuraSound 3D")
      .setContentText("پایش کتابخانه موسیقی فعال است")
      .setOngoing(true).build();
    startForeground(712,n);
  }
  @Override public int onStartCommand(Intent i,int flags,int id){
    // MediaStore is indexed by Android; app refreshes the library when opened.
    // Service stays foreground while Android permits it, with a user-visible notification.
    return START_STICKY;
  }
  @Override public void onDestroy(){super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
