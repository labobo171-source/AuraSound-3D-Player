import sys
p=sys.argv[1]
s=open(p,encoding="utf-8").read()
perms=['<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />',
'<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
'<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
'<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />']
for perm in perms:
 if perm not in s: s=s.replace('<application',perm+'\n    <application',1)
plugin='<com.aurasound.player.AuraNativePlugin />'
if 'AuraNativePlugin' not in s:
 s=s.replace('<application', '<application',1)
 # Capacitor plugin is registered manually through MainActivity, service is declared here
 s=s.replace('</application>', '<service android:name="com.aurasound.player.AuraScanService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n</application>')
open(p,'w',encoding='utf-8').write(s)
