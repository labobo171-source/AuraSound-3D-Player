import os,sys
p=sys.argv[1]
s=open(p,encoding="utf-8").read()
if "AuraNativePlugin" not in s:
 s=s.replace("import com.getcapacitor.BridgeActivity;", "import com.getcapacitor.BridgeActivity;\nimport com.aurasound.player.AuraNativePlugin;")
 s=s.replace("public class MainActivity extends BridgeActivity {", "public class MainActivity extends BridgeActivity {\n  @Override public void onCreate(android.os.Bundle savedInstanceState) {\n    registerPlugin(AuraNativePlugin.class);\n    super.onCreate(savedInstanceState);\n  }")
open(p,"w",encoding="utf-8").write(s)
