package com.aurasound.player;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentUris;
import android.os.Build;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.util.*;

@CapacitorPlugin(name="AuraNative", permissions={
  @Permission(alias="audio", strings={"android.permission.READ_MEDIA_AUDIO"})
})
public class AuraNativePlugin extends Plugin {
  @PluginMethod public void scanAudio(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 33 && getPermissionState("audio") != PermissionState.GRANTED) {
      requestPermissionForAlias("audio", call, "scanAudioPermissionCallback");
      return;
    }
    doScanAudio(call);
  }
  @PermissionCallback private void scanAudioPermissionCallback(PluginCall call) {
    if (getPermissionState("audio") == PermissionState.GRANTED) doScanAudio(call);
    else call.reject("اجازه دسترسی به موسیقی داده نشد.");
  }
  private void doScanAudio(PluginCall call) {
    JSArray result = new JSArray();
    String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE,
      MediaStore.Audio.Media.DATE_MODIFIED, MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION};
    String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
    try (Cursor c = getContext().getContentResolver().query(
      MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null,
      MediaStore.Audio.Media.TITLE + " ASC")) {
      if (c != null) while (c.moveToNext()) {
        long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
        Uri uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
        JSObject t=new JSObject();
        t.put("id","media:"+id);
        t.put("uri",uri.toString());
        t.put("name",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)));
        t.put("filename",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)));
        t.put("size",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
        t.put("date",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED))*1000L);
        t.put("album",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)));
        t.put("artist",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)));
        t.put("duration",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)));
        result.put(t);
      }
      call.resolve(new JSObject().put("tracks",result));
    } catch(Exception e) { call.reject("MediaStore scan failed: "+e.getMessage(),e); }
  }
  @PluginMethod public void shareText(PluginCall call) {
    String title=call.getString("title","AuraSound");
    String text=call.getString("text","");
    Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
    i.putExtra(Intent.EXTRA_SUBJECT,title); i.putExtra(Intent.EXTRA_TEXT,text);
    getActivity().startActivity(Intent.createChooser(i,"اشتراک‌گذاری"));
    call.resolve();
  }
  @PluginMethod public void startBackgroundScan(PluginCall call) {
    Intent i=new Intent(getContext(),AuraScanService.class);
    if(Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);
    call.resolve();
  }
}
