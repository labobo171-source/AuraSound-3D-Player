package com.aurasound.player;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentUris;
import android.os.Build;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.media.MediaMetadata;
import android.view.KeyEvent;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.util.*;

@CapacitorPlugin(name="AuraNative", permissions={
  @Permission(alias="audio", strings={"android.permission.READ_MEDIA_AUDIO"})
})
public class AuraNativePlugin extends Plugin {
  private MediaSession carMediaSession;

  private void ensureMediaSession() {
    if (Build.VERSION.SDK_INT < 21 || carMediaSession != null) return;
    carMediaSession = new MediaSession(getContext(), "AuraSound3D");
    carMediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS |
        MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
    carMediaSession.setCallback(new MediaSession.Callback() {
      @Override public void onPlay() { emitMediaAction("play"); }
      @Override public void onPause() { emitMediaAction("pause"); }
      @Override public void onSkipToNext() { emitMediaAction("next"); }
      @Override public void onSkipToPrevious() { emitMediaAction("previous"); }
      @Override public void onSeekTo(long position) {
        JSObject data = new JSObject(); data.put("action", "seekTo"); data.put("position", position);
        notifyListeners("mediaControl", data);
      }
      @Override public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
        KeyEvent event = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
        if (event != null && event.getAction() == KeyEvent.ACTION_DOWN) {
          switch (event.getKeyCode()) {
            case KeyEvent.KEYCODE_MEDIA_PLAY: emitMediaAction("play"); return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: emitMediaAction("pause"); return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: emitMediaAction("toggle"); return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT: emitMediaAction("next"); return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: emitMediaAction("previous"); return true;
          }
        }
        return super.onMediaButtonEvent(mediaButtonIntent);
      }
    });
    carMediaSession.setActive(true);
  }

  private void emitMediaAction(String action) {
    JSObject data = new JSObject(); data.put("action", action);
    notifyListeners("mediaControl", data);
  }

  @PluginMethod public void updateCarMediaSession(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 21) {
      ensureMediaSession();
      String title = call.getString("title", "AuraSound 3D");
      String artist = call.getString("artist", "AuraSound 3D Player");
      boolean playing = call.getBoolean("playing", false);
      long position = call.getLong("position", 0L);
      long duration = call.getLong("duration", 0L);
      carMediaSession.setMetadata(new MediaMetadata.Builder()
        .putString(MediaMetadata.METADATA_KEY_TITLE, title)
        .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
        .putString(MediaMetadata.METADATA_KEY_ALBUM, "AuraSound 3D")
        .putLong(MediaMetadata.METADATA_KEY_DURATION, Math.max(0L, duration))
        .build());
      long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
        PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT |
        PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO;
      carMediaSession.setPlaybackState(new PlaybackState.Builder()
        .setActions(actions)
        .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
          Math.max(0L, position), 1.0f)
        .build());
      carMediaSession.setActive(true);
    }
    call.resolve();
  }

  @PluginMethod public void scanAudio(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 33 && getPermissionState("audio") != PermissionState.GRANTED) {
      requestPermissionForAlias("audio", call, "scanAudioPermissionCallback");
      return;
    }
    doScanAudio(call);
  }
  @PermissionCallback private void scanAudioPermissionCallback(PluginCall call) {
    if (getPermissionState("audio") == PermissionState.GRANTED) doScanAudio(call);
    else call.reject("اجازه دسترسی به موسیقی داده نشد.");
  }
  private void doScanAudio(PluginCall call) {
    JSArray result = new JSArray();
    String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE,
      MediaStore.Audio.Media.DATE_MODIFIED, MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION};
    String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
    try (Cursor c = getContext().getContentResolver().query(
      MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null,
      MediaStore.Audio.Media.TITLE + " ASC")) {
      if (c != null) while (c.moveToNext()) {
        long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
        Uri uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
        JSObject t=new JSObject();
        t.put("id","media:"+id);
        t.put("uri",uri.toString());
        t.put("name",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)));
        t.put("filename",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)));
        t.put("size",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
        t.put("date",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED))*1000L);
        t.put("album",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)));
        t.put("artist",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)));
        t.put("duration",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)));
        result.put(t);
      }
      call.resolve(new JSObject().put("tracks",result));
    } catch(Exception e) { call.reject("MediaStore scan failed: "+e.getMessage(),e); }
  }
  @PluginMethod public void shareText(PluginCall call) {
    String title=call.getString("title","AuraSound");
    String text=call.getString("text","");
    Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
    i.putExtra(Intent.EXTRA_SUBJECT,title); i.putExtra(Intent.EXTRA_TEXT,text);
    getActivity().startActivity(Intent.createChooser(i,"اشتراک‌گذاری"));
    call.resolve();
  }
  @PluginMethod public void startBackgroundScan(PluginCall call) {
    Intent i=new Intent(getContext(),AuraScanService.class);
    if(Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);
    call.resolve();
  }

  @Override public void handleOnDestroy() {
    if (carMediaSession != null) {
      carMediaSession.setActive(false);
      carMediaSession.release();
      carMediaSession = null;
    }
    super.handleOnDestroy();
  }
}
