package com.aurasound.player;

import android.content.Intent;
import android.content.Context;
import android.database.Cursor;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentUris;
import android.os.Build;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.media.MediaMetadata;
import android.media.AudioManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.view.KeyEvent;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.util.*;

@CapacitorPlugin(name="AuraNative", permissions={
  @Permission(alias="audio", strings={"android.permission.READ_MEDIA_AUDIO", "android.permission.READ_EXTERNAL_STORAGE"})
})
public class AuraNativePlugin extends Plugin {
  private MediaSession carMediaSession;
  private AudioManager audioManager;
  private AudioFocusRequest audioFocusRequest;
  private boolean hasAudioFocus = false;
  private String cachedArtworkUri = null;
  private Bitmap cachedArtwork = null;
  private Bitmap fallbackArtwork = null;
  private ContentObserver mediaStoreObserver;

  private final AudioManager.OnAudioFocusChangeListener focusChangeListener = change -> {
    JSObject data = new JSObject();
    switch (change) {
      case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT: data.put("action", "focusLostTransient"); break;
      case AudioManager.AUDIOFOCUS_LOSS: data.put("action", "focusLost"); break;
      case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK: data.put("action", "focusDuck"); break;
      case AudioManager.AUDIOFOCUS_GAIN: data.put("action", "focusGain"); break;
      default: return;
    }
    notifyListeners("mediaInterruption", data);
    if (change == AudioManager.AUDIOFOCUS_LOSS) abandonAudioFocus();
  };

  private int requestAudioFocusInternal() {
    if (audioManager == null) audioManager = (AudioManager)getContext().getSystemService(Context.AUDIO_SERVICE);
    if (audioManager == null) return AudioManager.AUDIOFOCUS_REQUEST_FAILED;
    if (Build.VERSION.SDK_INT >= 26) {
      if (audioFocusRequest == null) {
        AudioAttributes attributes = new AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_MEDIA)
          .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
          .build();
        audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
          .setAudioAttributes(attributes)
          .setAcceptsDelayedFocusGain(false)
          .setWillPauseWhenDucked(false)
          .setOnAudioFocusChangeListener(focusChangeListener)
          .build();
      }
      int result = audioManager.requestAudioFocus(audioFocusRequest);
      hasAudioFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
      return result;
    }
    @SuppressWarnings("deprecation")
    int result = audioManager.requestAudioFocus(focusChangeListener,
      AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
    hasAudioFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    return result;
  }

  private void abandonAudioFocus() {
    if (audioManager == null || !hasAudioFocus) return;
    if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
      audioManager.abandonAudioFocusRequest(audioFocusRequest);
    } else {
      //noinspection deprecation
      audioManager.abandonAudioFocus(focusChangeListener);
    }
    hasAudioFocus = false;
  }

  private Bitmap loadEmbeddedArtwork(String contentUri) {
    if (contentUri == null || !contentUri.startsWith("content://")) return null;
    if (contentUri.equals(cachedArtworkUri)) return cachedArtwork;
    cachedArtworkUri = contentUri;
    cachedArtwork = null;
    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
    try {
      retriever.setDataSource(getContext(), Uri.parse(contentUri));
      byte[] bytes = retriever.getEmbeddedPicture();
      if (bytes == null) return null;
      Bitmap source = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
      if (source == null) return null;
      int max = 512;
      if (source.getWidth() <= max && source.getHeight() <= max) {
        cachedArtwork = source;
      } else {
        float scale = Math.min((float)max/source.getWidth(), (float)max/source.getHeight());
        cachedArtwork = Bitmap.createScaledBitmap(source,
          Math.max(1, Math.round(source.getWidth()*scale)),
          Math.max(1, Math.round(source.getHeight()*scale)), true);
        if (cachedArtwork != source) source.recycle();
      }
      return cachedArtwork;
    } catch (Exception ignored) {
      return null;
    } finally {
      try { retriever.release(); } catch (Exception ignored) {}
    }
  }

  private Bitmap loadFallbackArtwork() {
    if (fallbackArtwork != null) return fallbackArtwork;
    try {
      Drawable drawable = getContext().getPackageManager()
        .getApplicationIcon(getContext().getApplicationInfo());
      int width = Math.max(1, drawable.getIntrinsicWidth());
      int height = Math.max(1, drawable.getIntrinsicHeight());
      Bitmap bitmap = Bitmap.createBitmap(Math.min(width, 512), Math.min(height, 512), Bitmap.Config.ARGB_8888);
      Canvas canvas = new Canvas(bitmap);
      drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
      drawable.draw(canvas);
      fallbackArtwork = bitmap;
      return fallbackArtwork;
    } catch (Exception ignored) {
      fallbackArtwork = BitmapFactory.decodeResource(getContext().getResources(), android.R.drawable.ic_media_play);
      return fallbackArtwork;
    }
  }

  private void ensureMediaSession() {
    if (Build.VERSION.SDK_INT < 21 || carMediaSession != null) return;
    carMediaSession = new MediaSession(getContext(), "AuraSound3D");
    carMediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS |
        MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
    carMediaSession.setCallback(new MediaSession.Callback() {
      @Override public void onPlay() { emitMediaAction("play"); }
      @Override public void onPause() { emitMediaAction("pause"); }
      @Override public void onSkipToNext() { emitMediaAction("next"); }
      @Override public void onSkipToPrevious() { emitMediaAction("previous"); }
      @Override public void onSeekTo(long position) {
        JSObject data = new JSObject(); data.put("action", "seekTo"); data.put("position", position);
        notifyListeners("mediaControl", data);
      }
      @Override public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
        KeyEvent event = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
        if (event != null && event.getAction() == KeyEvent.ACTION_DOWN) {
          switch (event.getKeyCode()) {
            case KeyEvent.KEYCODE_MEDIA_PLAY: emitMediaAction("play"); return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: emitMediaAction("pause"); return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: emitMediaAction("toggle"); return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT: emitMediaAction("next"); return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: emitMediaAction("previous"); return true;
          }
        }
        return super.onMediaButtonEvent(mediaButtonIntent);
      }
    });
    carMediaSession.setActive(true);
  }

  private void emitMediaAction(String action) {
    JSObject data = new JSObject(); data.put("action", action);
    notifyListeners("mediaControl", data);
  }

  @PluginMethod public void updateCarMediaSession(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 21) {
      ensureMediaSession();
      String title = call.getString("title", "AuraSound 3D");
      String artist = call.getString("artist", "AuraSound 3D Player");
      boolean playing = call.getBoolean("playing", false);
      long position = call.getLong("position", 0L);
      long duration = call.getLong("duration", 0L);
      MediaMetadata.Builder metadata = new MediaMetadata.Builder()
        .putString(MediaMetadata.METADATA_KEY_TITLE, title)
        .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
        .putString(MediaMetadata.METADATA_KEY_ALBUM, "AuraSound 3D")
        .putLong(MediaMetadata.METADATA_KEY_DURATION, Math.max(0L, duration));
      Bitmap artwork = loadEmbeddedArtwork(call.getString("artworkUri"));
      if (artwork == null) artwork = loadFallbackArtwork();
      if (artwork != null) {
        metadata.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artwork);
        metadata.putBitmap(MediaMetadata.METADATA_KEY_ART, artwork);
      }
      carMediaSession.setMetadata(metadata.build());
      long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE |
        PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT |
        PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO;
      carMediaSession.setPlaybackState(new PlaybackState.Builder()
        .setActions(actions)
        .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
          Math.max(0L, position), 1.0f)
        .build());
      carMediaSession.setActive(true);
    }
    call.resolve();
  }


  @PluginMethod public void requestAudioFocus(PluginCall call) {
    int result = requestAudioFocusInternal();
    JSObject response = new JSObject();
    response.put("granted", result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED);
    call.resolve(response);
  }

  @PluginMethod public void abandonAudioFocus(PluginCall call) {
    abandonAudioFocus();
    call.resolve();
  }

  private JSArray queryAudioTracks() throws Exception {
    JSArray result = new JSArray();
    String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.SIZE,
      MediaStore.Audio.Media.DATE_MODIFIED, MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION};
    String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
    try (Cursor c = getContext().getContentResolver().query(
      MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null,
      MediaStore.Audio.Media.TITLE + " ASC")) {
      if (c != null) while (c.moveToNext()) {
        long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
        Uri uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
        JSObject t=new JSObject();
        t.put("id","media:"+id); t.put("uri",uri.toString());
        t.put("name",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)));
        t.put("filename",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)));
        t.put("size",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)));
        t.put("date",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED))*1000L);
        t.put("album",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)));
        t.put("artist",c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)));
        t.put("duration",c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)));
        result.put(t);
      }
    }
    return result;
  }

  private void registerMediaStoreObserver() {
    if (mediaStoreObserver != null) return;
    mediaStoreObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
      @Override public void onChange(boolean selfChange, Uri uri) {
        super.onChange(selfChange, uri);
        // Android's media scanner publishes completed audio imports through MediaStore.
        // A short delay lets metadata indexing finish before the library snapshot is sent.
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
          try {
            JSObject payload = new JSObject();
            payload.put("tracks", queryAudioTracks());
            notifyListeners("newAudioFiles", payload);
          } catch (Exception e) { android.util.Log.w("AuraSound", "MediaStore refresh failed", e); }
        }, 700);
      }
    };
    getContext().getContentResolver().registerContentObserver(
      MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, mediaStoreObserver);
    try {
      JSObject payload = new JSObject(); payload.put("tracks", queryAudioTracks());
      notifyListeners("newAudioFiles", payload);
    } catch (Exception e) { android.util.Log.w("AuraSound", "Initial MediaStore sync failed", e); }
  }

  @PluginMethod public void startWatchingLibrary(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 23 && getPermissionState("audio") != PermissionState.GRANTED) {
      requestPermissionForAlias("audio", call, "watchLibraryPermissionCallback");
      return;
    }
    registerMediaStoreObserver();
    call.resolve();
  }

  @PermissionCallback private void watchLibraryPermissionCallback(PluginCall call) {
    if (getPermissionState("audio") == PermissionState.GRANTED) {
      registerMediaStoreObserver(); call.resolve();
    } else call.reject("برای افزودن خودکار آهنگ‌ها، اجازه دسترسی به فایل‌های صوتی لازم است.");
  }

  @PluginMethod public void scanAudio(PluginCall call) {
    if (Build.VERSION.SDK_INT >= 33 && getPermissionState("audio") != PermissionState.GRANTED) {
      requestPermissionForAlias("audio", call, "scanAudioPermissionCallback");
      return;
    }
    doScanAudio(call);
  }
  @PermissionCallback private void scanAudioPermissionCallback(PluginCall call) {
    if (getPermissionState("audio") == PermissionState.GRANTED) doScanAudio(call);
    else call.reject("اجازه دسترسی به موسیقی داده نشد.");
  }
  private void doScanAudio(PluginCall call) {
    try {
      call.resolve(new JSObject().put("tracks", queryAudioTracks()));
    } catch(Exception e) { call.reject("MediaStore scan failed: "+e.getMessage(),e); }
  }
  @PluginMethod public void shareText(PluginCall call) {
    String title=call.getString("title","AuraSound");
    String text=call.getString("text","");
    Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
    i.putExtra(Intent.EXTRA_SUBJECT,title); i.putExtra(Intent.EXTRA_TEXT,text);
    getActivity().startActivity(Intent.createChooser(i,"اشتراک‌گذاری"));
    call.resolve();
  }
  @PluginMethod public void startBackgroundScan(PluginCall call) {
    Intent i=new Intent(getContext(),AuraScanService.class);
    if(Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);
    call.resolve();
  }

  @Override public void handleOnDestroy() {
    if (mediaStoreObserver != null) {
      try { getContext().getContentResolver().unregisterContentObserver(mediaStoreObserver); } catch (Exception ignored) {}
      mediaStoreObserver = null;
    }
    abandonAudioFocus();
    if (carMediaSession != null) {
      carMediaSession.setActive(false);
      carMediaSession.release();
      carMediaSession = null;
    }
    super.handleOnDestroy();
  }
}
